<?php 

session_start();

    if($_SESSION["login"] != "1"){
        header("Location: ..//index.html");
    }   

require_once ('process/dbh.php');
$sql = "SELECT * from `employee`";
$result = mysqli_query($conn, $sql);
$rowcount = mysqli_num_rows( $result );


$sql2 = "SELECT * from `daily` WHERE d_date = curdate()";
$result2 = mysqli_query($conn, $sql2);

$sql3 = "SELECT SUM(total) from `daily` WHERE MONTH(d_date) = MONTH(CURRENT_DATE())
AND YEAR(d_date) = YEAR(CURRENT_DATE())";
$dailysum = mysqli_query($conn, $sql3);

$dailysum = mysqli_fetch_assoc($dailysum);
$sum1=0;
foreach($dailysum as $d){
	$sum1+=$d;
}



$sql3 = "SELECT SUM(total) from `invoice` WHERE MONTH(date) = MONTH(CURRENT_DATE())
AND YEAR(date) = YEAR(CURRENT_DATE())";
$dailysum = mysqli_query($conn, $sql3);

$dailysum = mysqli_fetch_assoc($dailysum);
$sum2=0;
foreach($dailysum as $d){
	$sum2+=$d;
}



$sql3 = "SELECT SUM(houres) from `dates` WHERE MONTH(date) = MONTH(CURRENT_DATE())
AND YEAR(date) = YEAR(CURRENT_DATE()) AND payed = 1";
$dailysum = mysqli_query($conn, $sql3);

$dailysum = mysqli_fetch_assoc($dailysum);
$sum3=0;
foreach($dailysum as $d){
	$sum3+=($d*15);
}


$sum1 = ($sum1-$sum2)-$sum3


?>


<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
</head>
<body>
	
<?php include 'navbar.php';?>

	 
	<div class="divider"></div>
	<div id="divimg">
	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Welcome  <?php echo $_SESSION["name"]; ?></h2>


	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Empolyee Numbers </h2>

		<?php
					echo "<h3 style='text-align: center;'>".$rowcount."</h3>";

			?>

<?php
    if(mysqli_num_rows($result2) == 0){
?>
<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo" style="text-align: center;">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Daily Sales</h2>
                    <form action="process/dailyprocess.php" method="POST" enctype="multipart/form-data">


                        

                        <div class="input-group">
		    				<input class="input--style-1" type="number" min="0" step="0.01"  placeholder="Daily Total Price" name="total" required="required" >
                        </div>


                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Save Daily Sales</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	<?php
}
?>

<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">This Mounth Earnings </h2>

<?php


if($sum1 > -1){
	echo "<h3 style='text-align: center; color: green;'>".$sum1."</h3>";
}else{
	echo "<h3 style='text-align: center; color: red;'>".$sum1."</h3>";
}


	?>



<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo" style="text-align: center;">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Enter Month to know Month Earnings</h2>
                    <form action="monthprocess.php" method="POST" enctype="multipart/form-data">


					<div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-1" type="month" placeholder="Month and year" name="date" required="required">
                                   
                                </div>
                            </div>
</div>

                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Search Earnings Month</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>





    <div class="p-t-20" style="text-align: center;">
                            <a class="btn btn--radius btn--green" type="submit" href="newadmin.php">Add New Admin</a>
                        </div>





	</div>
</body>
</html>