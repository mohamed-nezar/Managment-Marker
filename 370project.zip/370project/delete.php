<?php
//including the database connection file
include("process/dbh.php");

//getting id of the data from url
$id = $_GET['id'];

//deleting the row from table

try {
    // First of all, let's begin a transaction
    $conn->begin_transaction();
    // A set of queries; if one fails, an exception should be thrown
    $result = mysqli_query($conn, "DELETE FROM employee WHERE id=$id");
    $result = mysqli_query($conn, "DELETE FROM dates WHERE emp_id=$id");
    $conn->commit();
    } catch (Exception $e) {
    $conn->rollback();
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Sorry There is Transaction')
    window.location.href='..//viewinvoice.php';
    </SCRIPT>");
    }




//redirecting to the display page (index.php in our case)
header("Location:viewemp.php");
?>

