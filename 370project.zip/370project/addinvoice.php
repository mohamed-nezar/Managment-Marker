<?php
session_start();

    if($_SESSION["login"] != "1"){
        header("Location: ..//index.html");
    }   
?>

<!DOCTYPE html>
<html>

<head>
   

    <!-- Title Page-->
    <title>Add Invoice | Admin Panel</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
<?php include 'navbar.php';?>

    
    <div class="divider"></div>




    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Invoice Info</h2>
                    <form action="process/addinvprocess.php" method="POST" enctype="multipart/form-data">


                        <p>Invoice Number</p>
                        <div class="row row-space">
                            <div class="col-2">

                            <?php
                        if(isset($_COOKIE['inv_num'])) {
                    ?>
                                <div class="input-group">
                                     <input class="input--style-1" type="text" value="<?php echo $_COOKIE['inv_num'];  ?>" placeholder="Invoice Number" name="inv_num" required="required">
                                </div>
                    <?php
                        } else {
                    ?>
                        <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="Invoice Number" name="inv_num" required="required">
                                </div>
                    <?php
                        }
                    ?>


                        </div>

                        
                            <div class="col-2">

                            <p>Store Name</p>

                        <?php
                        if(isset($_COOKIE['store_name'])) {
                    ?>
                                <div class="input-group">
                                     <input class="input--style-1" type="text" value="<?php echo $_COOKIE['store_name'];  ?>" placeholder="Store Name" name="store_name" required="required">
                                </div>
                    <?php
                        } else {
                    ?>
                        <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="Store Name" name="store_name" required="required">
                                </div>
                    <?php
                        }
                    ?>
                        

                            </div>
                        </div>
                   



                        <p>Invoice Date</p>
                        <div class="row row-space">
                            <div class="col-2">

                            <?php
                        if(isset($_COOKIE['date'])) {
                    ?>
                                <div class="input-group">
                                    <input class="input--style-1" type="date" placeholder="Invoice Date" value="<?php echo $_COOKIE['date'];  ?>" name="invoicedate" required="required">
                                </div>

                    <?php
                        } else {
                    ?>
                                <div class="input-group">
                                    <input class="input--style-1" type="date" placeholder="Invoice Date" name="invoicedate" required="required">
                                </div>
                    <?php
                        }
                    ?>




                            </div>
                            <div class="col-2">
                            <p>Invoice Total Price</p>

                            <?php
                        if(isset($_COOKIE['total'])) {
                    ?>

                                <div class="input-group">
                                        <input class="input--style-1" type="number" min="0" step="0.01" value="<?php echo $_COOKIE['total'];  ?>"  placeholder="Invoice Total Price" name="total" required="required" >
                                </div>
                    <?php
                        } else {
                    ?>
                                <div class="input-group">
                                        <input class="input--style-1" type="number" min="0" step="0.01"  placeholder="Invoice Total Price" name="total" required="required" >
                                </div>
                    <?php
                        }
                    ?>

                            </div>
                        </div>
                        


                        <p>Invoice Content</p>

                        <?php
                        if(isset($_COOKIE['inv_content'])) {
                    ?>
                                <div class="input-group">
                                     <input class="input--style-1" type="text" value="<?php echo $_COOKIE['inv_content'];  ?>" placeholder="Invoice Content" name="inv_content" required="required">
                                </div>
                    <?php
                        } else {
                    ?>
                        <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="Invoice Content" name="inv_content" required="required">
                                </div>
                    <?php
                        }
                    ?>




                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Save Invoice</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body>

</html>
<!-- end document-->
