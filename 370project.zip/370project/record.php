<?php

session_start();

    if($_SESSION["login"] != "1"){
        header("Location: ..//index.html");
    }   

require_once ('process/dbh.php');
$sql = "SELECT * FROM `employee` WHERE 1";


//echo "$sql";
$result = mysqli_query($conn, $sql);
if(isset($_POST['update']))
{

	$id = mysqli_real_escape_string($conn, $_POST['id']);

	//$salary = mysqli_real_escape_string($conn, $_POST['salary']);





	// $result = mysqli_query($conn, "UPDATE `employee` SET `firstName`='$firstname',`lastName`='$lastname',`email`='$email',`password`='$email',`gender`='$gender',`contact`='$contact',`nid`='$nid',`salary`='$salary',`address`='$address',`dept`='$dept',`degree`='$degree' WHERE id=$id");


$result = mysqli_query($conn, "UPDATE `dates` SET `payed`='1' WHERE id=$id");
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Updated')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>




<?php
	$id = (isset($_GET['id']) ? $_GET['id'] : '');
	$sql = "SELECT * from `employee` WHERE id=$id";
	$result = mysqli_query($conn, $sql);
	if($result){
	    while($res = mysqli_fetch_assoc($result)){
	        $firstname = $res['firstName'];
	        $id = $res['id'];
	        $lastname = $res['lastName'];
	        $email = $res['email'];
	        $phone = $res['phone'];
	        $address = $res['address'];
	        $gender = $res['gender'];
	        $startDate = $res['startDate'];
	        $dept = $res['dept'];
	        $houres = $res['houres'];
        }
    }

    $sql2 = "SELECT * FROM `vacation` WHERE emp_id = $id ";
    $holiday = mysqli_query($conn, $sql2);
    $holiday = mysqli_fetch_assoc($holiday);

    $sql = "SELECT * from `dates` where emp_id = $id";
    $result2 = mysqli_query($conn, $sql);

    if($holiday && strtotime($holiday['end_vac']) <= time()){
        $result = mysqli_query($conn, "DELETE FROM vacation WHERE emp_id=$id");
        header("Refresh:0");
    }
 
?>

<html>
<head>
	<title>Employee Record</title>
	<!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="styleview.css">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>
<body>
<?php include 'navbar.php';?>

	
	<div class="divider"></div>
	

		<!-- <form id = "registration" action="edit.php" method="POST"> -->
	<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Employee Info</h2>

                    <h4>Employee Name:: <?php echo $firstname; echo ' '.$lastname; ?></h4>
                    <h4>Employee E-mail:: <?php echo $email; ?></h4>
                    <h4>Employee Phone:: <?php echo $phone; ?></h4>
                    <h4>Employee Address:: <?php echo $address; ?></h4>
                    <h4>Employee Gender:: <?php echo $gender; ?></h4>
                    <h4>Employee Start Date:: <?php echo $startDate; ?></h4>
                    <h4>Employee Department:: <?php echo $dept; ?></h4>


                </div>
            </div>


                    <?php
                        if($holiday){
                    ?>
                    <h2 style="color: green; text-align: center; padding: 30px 0px;">The Employee is on Vacation</h2> <h2 style="color: green; text-align: center; padding-bottom: 30px;"> From <?php echo $holiday['start_vac'];  ?> To <?php echo $holiday['end_vac'];  ?> </h2>
                    <?php
                        }else{
                    ?>
                    <form action="process/addVacation.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $id;?>">
                        <div class="row row-space" style="margin-top: 30px;">
                            <div class="col-2">
                               <p>Start Vacation Date</p>
                                <div class="input-group">
                                    <input class="input--style-1" type="date" placeholder="Start Date" name="start_vac" required="required">
                                </div>
                            </div>
                            <div class="col-2">
                            <p>End Vacation Date</p>
                                <div class="input-group">
                                        <input class="input--style-1" type="date"  placeholder="End Date" name="end_vac" required="required" >
                                </div>
                            </div>


                            <div class="input-group">
                            <button class="btn btn--radius btn--green center" type="submit">Save Vacation</button>
                        </div>

                        </div>
                    </form>

                    <?php
                        }
                    ?>
                        





            <table>
			<tr>

				<th align = "center">Date</th>
				<th align = "center">houres</th>
				<th style="text-align: center;">Total Salary</th>

				<th align = "center">Options</th>
			</tr>

			<?php
				while ($emp = mysqli_fetch_assoc($result2)) {
					echo "<tr>";

                    $month = date("m",strtotime($emp['date']));
                    $year = date("y",strtotime($emp['date']));

					echo "<td>".$year."-".$month."</td>";
					echo "<td>".$emp['houres']."</td>";

					$x = $emp['houres']*15;
					echo "<td>".$x."</td>";
                    
                    if($emp['payed'] == '0'){
					echo "<td><form id = 'registration' action='record.php' method='POST'>    
                        <input type='hidden' name='id' id='textField' value=". $emp['id']." required='required'><br><br>
                        <div>
                            <button class='btn btn--radius btn--green' type='submit' name='update'>Not Payed</button>
                        </div>
						</form> </td>";
					}else{
						echo "<td style='color: green;'> Payed </td>";
					}
				}


			?>

		</table>

        </div>
    </div>


     <!-- Jquery JS-->
    <!-- <script src="vendor/jquery/jquery.min.js"></script>
   
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

   
    <script src="js/global.js"></script> -->
</body>
</html>
