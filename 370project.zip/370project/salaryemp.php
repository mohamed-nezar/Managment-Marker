

<?php


session_start();

    if($_SESSION["login"] != "1"){
        header("Location: ..//index.html");
    }   

require_once ('process/dbh.php');
// $sql = "SELECT * from `employee`";

$sql = "SELECT * FROM employee WHERE  NOT EXISTS (SELECT 1 FROM dates WHERE  employee.id = dates.emp_id AND MONTH(dates.date) = MONTH(CURRENT_DATE())
AND YEAR(dates.date) = YEAR(CURRENT_DATE()));";


$result = mysqli_query($conn, $sql);


if(isset($_POST['update']))
{

	$id = mysqli_real_escape_string($conn, $_POST['id']);
	$houres = mysqli_real_escape_string($conn, $_POST['hour']);
	//$salary = mysqli_real_escape_string($conn, $_POST['salary']);

	$result = mysqli_query($conn, "UPDATE `employee` SET `houres`='$houres' WHERE id=$id");


	$emp_id = $_POST['id'];
	$date = date("Y/m/d");
	$houres = $_POST['hour'];
	$payed = 0;

	$sql = "INSERT INTO `dates`( `emp_id`, `date`, `houres`, `payed`) VALUES ('$emp_id','$date','$houres','$payed')";
    $result = mysqli_query($conn, $sql);

	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Updated')
    window.location.href='salaryemp.php';
    </SCRIPT>");
	
}


if(isset($_POST['update2']))
{

	$name = mysqli_real_escape_string($conn, $_POST['name']);
	//$salary = mysqli_real_escape_string($conn, $_POST['salary']);


	$result = mysqli_query($conn, "SELECT * from `employee` WHERE (firstName = '$name' or lastName = '$name') AND NOT EXISTS (SELECT 1 FROM dates WHERE  employee.id = dates.emp_id AND MONTH(dates.date) = MONTH(CURRENT_DATE())
	AND YEAR(dates.date) = YEAR(CURRENT_DATE()))");


	if(mysqli_num_rows($result) == 0){
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Empolyee Not Found')
    window.location.href='salaryemp.php';
    </SCRIPT>");
	}
	
}


?>





<html>
<head>
	<title>Salary Table</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/datatables/datatables.css">

</head>
<body>
	
<?php include 'navbar.php';?>

	 
	<!-- <div class="divider"></div>
	<div id="divimg"> -->




	<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo" style="text-align: center;">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Search For Employee</h2>
                    <form action="salaryemp.php" method="POST" enctype="multipart/form-data" >


					<div class="row row-space" style="float: center; !important">
                            <div class="col-2">
                                <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="Employee Name" name="name" required="required">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
								<button class="btn btn--radius btn--green" type="submit" name='update2'>Search Now</button>
                                </div>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>

	
	<table id="datatable" class="datatable" >
			<tr>
				<th style="text-align: center;">Emp. ID</th>
				<th  style="text-align: center;">FirstName</th>
				<th style="text-align: center;">LastName</th>
				<th style="text-align: center;">houres</th>
				
				
			</tr>
			
			<?php
				while ($employee = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$employee['id']."</td>";
					echo "<td>".$employee['firstName']."</td>";
					echo "<td>".$employee['lastName']."</td>";
					
					echo "<td>عدد ساعات الشهر<form id = 'registration' action='salaryemp.php' method='POST'>    
					    <input type='number' name='hour' min='0' required='required'>
                        <input type='hidden' name='id' id='textField' value=". $employee['id']." required='required'><br><br>
                        <div class='p-t-20'>
                            <button class='btn btn--radius btn--green' type='submit' name='update'>Submit</button>
                        </div>
						</form> </td>";
					
				}


			?>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/datatables/1.9.4/jquery.dataTables.min.js"></script>
		<script src="js/datatables/datatables.js"></script>
		<script type="text/javascript"></script>
			<script type="bootstrap.bundle.min.js"></script>
			<script type="bootstrap.bundle.js"></script>
			<script type="dataTables.bootstrap4.min.js"></script>
			<script type ="jquery.dataTables.min.js"></script>
			<script type="jquery-3.3.1.slim.min.js"></script>
			<script type ="font-awesome.min.css"></script>
			<script type="bootstrap.bundle.min.js"></script>
			<script type="bootstrap.bundle.js"></script>
			<script type="dataTables.bootstrap4.min.js"></script>
			<script type ="jquery.dataTables.min.js"></script>
			<script type="jquery-3.3.1.slim.min.js"></script>
			<script type ="font-awesome.min.css"></script>
			<script >
		$(document).ready(function() {
			$('.datatable').dataTable({
				"sPaginationType": "bs_four_button"
			});	
			$('.datatable').each(function(){
				var datatable = $(this);
				// SEARCH - Add the placeholder for Search and Turn this into in-line form control
				var search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
				search_input.attr('placeholder', 'Search');
				search_input.addClass('form-control input-sm');
				// LENGTH - Inline-Form control
				var length_sel = datatable.closest('.dataTables_wrapper').find('div[id$=_length] select');
				length_sel.addClass('form-control input-sm');
			});
		});
		 </script>
</body>
</html>