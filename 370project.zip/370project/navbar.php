
	<header>
		<nav>
		<h1>Market Mangment</h1>
		<h1 style="padding-left: 20px;"><?php echo $_SESSION["name"]; ?></h1>

			<ul id="navli">
			<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
                <li><a class="homeblack" href="addemp.php">Add Employee</a></li>
                <li><a class="homeblack" href="viewemp.php">View Employee</a></li>
                <li><a class="homeblack" href="addinvoice.php">Add Invoice</a></li>
                <li><a class="homeblack" href="viewinvoice.php">View Invoice</a></li>
				<li><a class="homeblack" href="salaryemp.php">Salary Table</a></li>

				<li><a class="homeblack" href="process/logout.php">Log Out</a></li>
			</ul>
		</nav>
	</header>