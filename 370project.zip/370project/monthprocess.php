<?php

session_start();

    if($_SESSION["login"] != "1"){
        header("Location: index.html");
    }   

require_once ('process/dbh.php');

$date = $_POST['date'];

$split_arr = explode("-", $date);

    $sql3 = "SELECT * from `daily` WHERE MONTH(d_date) = $split_arr[1]
    AND YEAR(d_date) = $split_arr[0]";
    $result = mysqli_query($conn, $sql3);
    $result2 = mysqli_query($conn, $sql3);
    


    if(mysqli_num_rows($result) > 0){

        $sum1=0;
        while ($dd = mysqli_fetch_assoc($result2)) {
            $sum1+=$dd['total'];
        }
        $x=$sum1;


    $sql3 = "SELECT SUM(total) from `invoice` WHERE MONTH(date) = $split_arr[1]
    AND YEAR(date) = $split_arr[0]";
    $dailysum = mysqli_query($conn, $sql3);
    
    $dailysum = mysqli_fetch_assoc($dailysum);
    $sum2=0;
    foreach($dailysum as $d){
        $sum2+=$d;
    }
    
    $y=$sum2;

    
    $sql3 = "SELECT SUM(houres) from `dates` WHERE MONTH(date) = $split_arr[1]
    AND YEAR(date) = $split_arr[0] AND payed = 1";
    $dailysum = mysqli_query($conn, $sql3);
    
    $dailysum = mysqli_fetch_assoc($dailysum);
    $sum3=0;
    foreach($dailysum as $d){
        $sum3+=($d*15);
    }
    $z=$sum3;

    
    $sum1 = ($sum1-$sum2)-$sum3;


}else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Nothing for this month')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
    // $last_id = $conn->insert_id;
    
?>


<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
</head>
<body>
	
<?php include 'navbar.php';?>

	 
	<div class="divider"></div>
	<div id="divimg">


	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Earning Of Month <?php echo $date; ?> </h2>

		<?php
					echo "<h3 style='text-align: center;'>Daily Earning ".$x."</h3>";
					echo "<h3 style='text-align: center;'>Invoice Total ".$y."</h3>";
					echo "<h3 style='text-align: center;'>Empolyee Total ".$z."</h3>";

                if($sum1 > -1){
					echo "<h3 style='text-align: center; color: green;'>".$sum1."</h3>";
                }else{
					echo "<h3 style='text-align: center; color: red;'>".$sum1."</h3>";
                }

			?>




<!-- <a class="homeblack" href="salaryemp.php">This Mounth Earnings</a> -->





	</div>
</body>
</html>