<?php

session_start();

    if($_SESSION["login"] != "1"){
        header("Location: ..//index.html");
    }      

require_once ('process/dbh.php');
$sql = "SELECT * from `invoice`";
$result = mysqli_query($conn, $sql);

?>
<html>
<head>
	<title>View Invoices</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>

	
	<?php include 'navbar.php';?>

	<div class="divider"></div>

		<table>
			<tr>

				<th align = "center">#Invoice</th>
				<th align = "center">Store name</th>
				<th align = "center">Invoice Content</th>
				<th align = "center">Total Price</th>
				<th align = "center">Date</th>
			
				
				<th align = "center">Options</th>
			</tr>

			<?php
				while ($inv = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$inv['inv_num']."</td>";
					echo "<td>".$inv['store_name']."</td>";
					echo "<td>".$inv['inv_content']."</td>";
					echo "<td>".$inv['total']."</td>";
					
					echo "<td>".$inv['date']."</td>";

					echo "<td> <a href=\"editinv.php?id=$inv[id]\">Edit</a> | <a href=\"deleteinv.php?id=$inv[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";

				}


			?>

		</table>
		
	
</body>
</html>