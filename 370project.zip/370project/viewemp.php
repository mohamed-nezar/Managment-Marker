<?php

session_start();

    if($_SESSION["login"] != "1"){
        header("Location: ..//index.html");
    }   

require_once ('process/dbh.php');
$sql = "SELECT * from `employee`";
$result = mysqli_query($conn, $sql);


if(isset($_POST['update']))
{

	$name = mysqli_real_escape_string($conn, $_POST['name']);
	//$salary = mysqli_real_escape_string($conn, $_POST['salary']);


	$result = mysqli_query($conn, "SELECT * from `employee` WHERE firstName = '$name' or lastName = '$name'");


	if(mysqli_num_rows($result) == 0){
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Empolyee Not Found')
    window.location.href='viewemp.php';
    </SCRIPT>");
	}
	
}

?>
<html>
<head>
	<title>View Employee</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>

	
	<?php include 'navbar.php';?>

	<div class="divider"></div>



	<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo" style="text-align: center;">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Search For Employee</h2>
                    <form action="viewemp.php" method="POST" enctype="multipart/form-data">


					<div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="Employee Name" name="name" required="required">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
								<button class="btn btn--radius btn--green" type="submit" name='update'>Search Now</button>
                                </div>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>


		<table>
			<tr>

				<th align = "center">Emp. ID</th>
				<th align = "center">first name</th>
				<th align = "center">last name</th>
				<th align = "center">Email</th>
				<th align = "center">start Date</th>
				<th align = "center">Gender</th>
				<th align = "center">phone</th>
				<th align = "center">Address</th>
				<th align = "center">Department</th>
				<th align = "center">houres</th>
				
				
				<th align = "center">Options</th>
			</tr>

			<?php
				while ($employee = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$employee['id']."</td>";
					echo "<td>".$employee['firstName']."</td>";
					echo "<td>".$employee['lastName']."</td>";
					
					echo "<td>".$employee['email']."</td>";
					echo "<td>".$employee['startDate']."</td>";
					echo "<td>".$employee['gender']."</td>";
					echo "<td>".$employee['phone']."</td>";
					echo "<td>".$employee['address']."</td>";
					echo "<td>".$employee['dept']."</td>";
					echo "<td>".$employee['houres']."</td>";

					echo "<td><a href=\"record.php?id=$employee[id]\">Record</a> |<a href=\"edit.php?id=$employee[id]\">Edit</a> | <a href=\"delete.php?id=$employee[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";

				}


			?>

		</table>
		
	
</body>
</html>