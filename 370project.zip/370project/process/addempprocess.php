<?php

require_once ('dbh.php');

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$gender = $_POST['gender'];
$dept = $_POST['dept'];
$houres = 0;
$startDate =$_POST['startDate'];
//echo "$birthday";

$sql2 = "SELECT * from `employee` WHERE email = '$email'";


$result = mysqli_query($conn, $sql2);

if(mysqli_num_rows($result) == 1){
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Email Already Exist')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}else{
    $sql = "INSERT INTO `employee`( `firstName`, `lastName`, `email`, `startDate`, `gender`, `phone`,  `address`, `dept`, `houres`) VALUES ('$firstName','$lastName','$email','$startDate','$gender','$phone','$address','$dept',$houres)";

    $result = mysqli_query($conn, $sql);
    
    // $last_id = $conn->insert_id;
    
    
    if(($result) == 1){
        
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Succesfully Registered')
        window.location.href='..//viewemp.php';
        </SCRIPT>");
        //header("Location: ..//aloginwel.php");
    }
    

}








?>