<?php

require_once ('dbh.php');

$id = $_POST['id'];
$start = $_POST['start_vac'];
$end = $_POST['end_vac'];

//echo "$birthday";


    $sql = "INSERT INTO `vacation`( `emp_id`, `start_vac`, `end_vac`) VALUES ('$id','$start','$end')";

    $result = mysqli_query($conn, $sql);
    
    // $last_id = $conn->insert_id;
    
    
    if(($result) == 1){
        
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Vacation Saved Succsse')
        window.location.href='javascript:history.back(1);';
        </SCRIPT>");
        //header("Location: ..//aloginwel.php");
    }



?>