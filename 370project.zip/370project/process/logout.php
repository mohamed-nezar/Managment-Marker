

<?php

require_once ('dbh.php');


session_start();

if($_SESSION["login"] == "1"){
// remove all session variables
session_unset(); 

// destroy the session 
// session_destroy(); 

	header("Location: ..//index.html");
}

else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Already logout')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>