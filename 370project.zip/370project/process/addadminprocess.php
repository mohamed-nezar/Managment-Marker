<?php

require_once ('dbh.php');

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

//echo "$birthday";

$sql2 = "SELECT * from `alogin` WHERE email = '$email'";


$result = mysqli_query($conn, $sql2);

if(mysqli_num_rows($result) == 1){
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Admin Already Exist')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}else{
    $sql = "INSERT INTO `alogin`( `name`, `email`, `password`) VALUES ('$name','$email','$password')";

    $result = mysqli_query($conn, $sql);
    
    // $last_id = $conn->insert_id;
    
    
    if(($result) == 1){
        
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Invoice Saved Registered')
        window.location.href='..//aloginwel.php';
        </SCRIPT>");
        //header("Location: ..//aloginwel.php");
    }
    

}











?>