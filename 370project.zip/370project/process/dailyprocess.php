<?php

require_once ('dbh.php');

$total = $_POST['total'];

//echo "$birthday";

$sql2 = "SELECT * from `daily` WHERE d_date = curdate()";
$result = mysqli_query($conn, $sql2);

    
    // $last_id = $conn->insert_id;
    
    
    if(mysqli_num_rows($result) == 1){
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Already Take The Sales of The Day')
        window.location.href='..//aloginwel.php';
        </SCRIPT>");
        //header("Location: ..//aloginwel.php");
    }else{
        $sql = "INSERT INTO `daily`( `total`, `d_date`) VALUES ('$total', curdate())";
        $result = mysqli_query($conn, $sql);
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Daily Total Saved Registered')
        window.location.href='..//aloginwel.php';
        </SCRIPT>");
    }









?>