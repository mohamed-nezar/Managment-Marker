<?php

require_once ('dbh.php');

$store_name = $_POST['store_name'];
$content = $_POST['inv_content'];
$inv_number = $_POST['inv_num'];
$invoicedate = $_POST['invoicedate'];
$total = $_POST['total'];

//echo "$birthday";

setcookie('store_name', $store_name, time() + (86400 * 30), "/"); // 86400 = 1 day
setcookie('inv_num', $inv_number, time() + (86400 * 30), "/"); // 86400 = 1 day
setcookie('inv_content', $content, time() + (86400 * 30), "/"); // 86400 = 1 day
setcookie('date', $invoicedate, time() + (86400 * 30), "/"); // 86400 = 1 day
setcookie('total', $total, time() + (86400 * 30), "/"); // 86400 = 1 day


$sql2 = "SELECT * from `invoice` WHERE inv_num = '$inv_number'";


$result = mysqli_query($conn, $sql2);

if(mysqli_num_rows($result) == 1){
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('The Invoice Already Exist')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}else{

    try {
        // First of all, let's begin a transaction
        $conn->begin_transaction();
        // A set of queries; if one fails, an exception should be thrown
        $sql = "INSERT INTO `invoice`( `inv_num`, `inv_content`, `store_name`, `total`, `date`) VALUES ('$inv_number','$content','$store_name','$total','$invoicedate')";
        $conn->commit();
        } catch (Exception $e) {
        $conn->rollback();
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Sorry There is Transaction')
        window.location.href='..//viewinvoice.php';
        </SCRIPT>");
        }


    $result = mysqli_query($conn, $sql);
    
    // $last_id = $conn->insert_id;
    
    
    if(($result) == 1){
        
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Invoice Saved Registered')
        window.location.href='..//viewinvoice.php';
        </SCRIPT>");
        //header("Location: ..//aloginwel.php");
    }


}



?>